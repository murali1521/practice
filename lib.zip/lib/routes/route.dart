import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hiiiiiiii/features/introduce_screen/view/introduce_screen.dart';
import 'package:hiiiiiiii/features/introduce_screen/view/introduce_screen1.dart';
import 'package:hiiiiiiii/features/login_screen/view/login_screen.dart';
import 'package:hiiiiiiii/features/sign_up_screen/view/sign_up_screen.dart';
import 'package:hiiiiiiii/routes/routes_constants.dart';

class AppRouter
{
  static final  GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  static final GoRouter router = GoRouter(
    navigatorKey: navigatorKey,
    initialLocation: RoutesConstants.signUp,
    routes: <RouteBase>[
      GoRoute(
        path: RoutesConstants.introduce,
        builder: (BuildContext context, GoRouterState state) {
          return IntroduceScreen1();
        }
      ),
      GoRoute(
        path: RoutesConstants.signIn,
        builder: (BuildContext context, GoRouterState state) {
          // TODO: Implement sign in screen
          return SignInScreen();
        }
      ),
      GoRoute(
        path: RoutesConstants.signUp,
        builder: (BuildContext context, GoRouterState state) {
          // TODO: Implement sign up screen
          return SignupScreen();
        }

      )
      // GoRoute(
      //   path: RoutesConstants.loginScreen,
      //   builder: (BuildContext context, GoRouterState state) {
      //     return const LoginScreen();
      //   }
      // ),
      // GoRoute(
      //   path: RoutesConstants.signUp,
      //   builder: (BuildContext context, GoRouterState state) {
      //     return const SignUpScreen();
      //   }
      // ),
    ],
  );
}