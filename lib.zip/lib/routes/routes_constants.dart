class RoutesConstants {
  static const String home = '/';
  static const String signIn = '/signIn';
  static const String signUp = '/signUp';
  static const String introduce = '/introduce';
    static const String forgotPassword = '/forgotPassword';
    static const String resetPassword = '/resetPassword';
    static const String verifyEmail = '/verifyEmail';
    static const String otpVerification = '/otpVerification';
    static const String profile = '/profile';
    static const String editProfile = '/editProfile';
    static const String changePassword = '/changePassword';
    static const String changeEmail = '/changeEmail';
  static const String changePhoneNumber = '/changePhoneNumber';
  static const String changeAddress = '/changeAddress';
  static const String changeLanguage = '/changeLanguage';
  static const String changeCurrency = '/changeCurrency';
  static const String changeTheme = '/changeTheme';
  static const String changeNotification = '/changeNotification';
}