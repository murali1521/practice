class LogoConstants {
  static const String appLogo = 'assets/icons/app_logo.png';
  static const String googleLogo = 'assets/icons/google_logo.png';
  static const String facebookLogo = 'assets/icons/facebook_logo.png';
  static const String twitterLogo = 'assets/icons/twitter_logo.png';
}